
from tkinter import *   # tkinter is the standard Python GUI
from PIL import ImageTk, Image
from forex_python.converter import CurrencyRates
from decimal import *

# from PIL import ImageTK, Image
# creates a blank window
root = Tk()

root.title("Currency Converter")
root.geometry("400x200")

options = ["USD", "EUR", "GBP", "JPY", "BRL", "AUD", "CAD",
           "CHF", "CNY", "MXN", "INR","RUB"]

start_clicked = StringVar()
def first_country(from_country):
    if from_country == options[0]:
        my_pic = Image.open("usa_flag.png")
    elif from_country == options[1]:
        my_pic = Image.open("eu_flag.png")
    elif from_country == options[2]:
        my_pic = Image.open("uk_flag.png")
    elif from_country == options[3]:
        my_pic = Image.open("japan_flag.png")
    elif from_country == options[4]:
        my_pic = Image.open("brazil_flag.png")
    elif from_country == options[5]:
        my_pic = Image.open("australia_flag.png")
    elif from_country == options[6]:
        my_pic = Image.open("canada_flag.png")
    elif from_country == options[7]:
        my_pic = Image.open("switzerland_flag.png")
    elif from_country == options[8]:
        my_pic = Image.open("china_flag.png")
    elif from_country == options[9]:
        my_pic = Image.open("mexico_flag.png")
    elif from_country == options[10]:
        my_pic = Image.open("india_flag.png")
    elif from_country == options[11]:
        my_pic = Image.open("russia_flag.png")

    resized = my_pic.resize((200, 100), Image.ANTIALIAS)
    new_pic = ImageTk.PhotoImage(resized)
    # better create the label once and update its image here
    flag_label.config(image=new_pic)
    flag_label.photo = new_pic # save a reference of the image



def second_country(to_country):
    if to_country == options[0]:
        my_pic = Image.open("usa_flag.png")
    elif to_country == options[1]:
        my_pic = Image.open("eu_flag.png")
    elif to_country == options[2]:
        my_pic = Image.open("uk_flag.png")
    elif to_country == options[3]:
        my_pic = Image.open("japan_flag.png")
    elif to_country == options[4]:
        my_pic = Image.open("brazil_flag.png")
    elif to_country == options[5]:
        my_pic = Image.open("australia_flag.png")
    elif to_country == options[6]:
        my_pic = Image.open("canada_flag.png")
    elif to_country == options[7]:
        my_pic = Image.open("switzerland_flag.png")
    elif to_country == options[8]:
        my_pic = Image.open("china_flag.png")
    elif to_country == options[9]:
        my_pic = Image.open("mexico_flag.png")
    elif to_country == options[10]:
        my_pic = Image.open("india_flag.png")
    elif to_country == options[11]:
        my_pic = Image.open("russia_flag.png")

    resized = my_pic.resize((200, 100), Image.ANTIALIAS)
    new_pic = ImageTk.PhotoImage(resized)
    # better create the label once and update its image here
    flag_label2.config(image=new_pic)
    flag_label2.photo = new_pic # save a reference of the image


...
dropdown = OptionMenu(root, start_clicked, *options, command=first_country)
...
# create the label for the flag image
flag_label = Label(root)
flag_label.grid(row=3, column=0)
flag_label2 = Label(root)
flag_label2.grid(row=3, column=1)


start_entry = StringVar()
start_entry = Entry(root)

end_clicked = StringVar()
end_clicked.set("Select a country to end")
dropdown2 = OptionMenu(root, end_clicked, *options, command=second_country)#, command=end_selected)

dropdown.config(font = (36))
dropdown2.config(font = (36))
start_entry.config(font=36)

dropdown.grid(row=0,column=0)
dropdown2.grid(row=0,column=1)
start_entry.grid(row=1,column=0)


conversion = CurrencyRates(force_decimal=True)
def activate_clicked():
    start = start_clicked.get()
    end = end_clicked.get()
    value = start_entry.get()
    finalValue = conversion.convert(start, end, Decimal(value))
    result = Label(root)

    result.config(text=finalValue)
    result.grid(row=1, column=1)
    result.config(font=36)
    finalValue = 0

activate = Button(root, text="Activate", command=activate_clicked)
activate.grid(row=2,column=1)
root.mainloop()     # stay open until you close it

